﻿Option Strict On

''' <summary>
''' Author Name:    Jesse Revell
''' Project Name:   CustomerInventory
''' Date:           July nth, 2019
''' Description     Keeps a list of cars and their details.
''' </summary>
''' 
Public Class frmCarInventory

    Private carList As New SortedList
    Private currentCarIdentificationNumber As String = String.Empty
    Private editMode As Boolean = False

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click

        Dim car As Car
        Dim carItem As ListViewItem

        If IsValidInput() = True Then

            editMode = True

            lblResult.Text = "It worked!"

            If currentCarIdentificationNumber.Trim.Length = 0 Then


                car = New Car(cmbMake.Text, tbModel.Text, cmbYear.Text, tbPrice.Text, chkNew.Checked)

                carList.Add(car.IdentificationNumber.ToString(), car)

            Else

                car = CType(carList.Item(currentCarIdentificationNumber), Car)

                car.Make = cmbMake.Text
                car.Model = tbModel.Text
                car.Year = cmbYear.Text
                car.Price = tbPrice.Text
                car.NewCar = chkNew.Checked
            End If

            lvwCars.Items.Clear()

            For Each carEntry As DictionaryEntry In carList

                carItem = New ListViewItem()

                car = CType(carEntry.Value, Car)

                carItem.Checked = car.NewCar
                carItem.SubItems.Add(car.IdentificationNumber.ToString())
                carItem.SubItems.Add(car.Make.ToString())
                carItem.SubItems.Add(car.Model.ToString())
                carItem.SubItems.Add(car.Year.ToString())
                carItem.SubItems.Add(car.Price.ToString())

                lvwCars.Items.Add(carItem)

            Next carEntry

            Reset()

            editMode = False

        End If
    End Sub

    Private Sub Reset()

        cmbMake.SelectedIndex = -1
        tbModel.Text = String.Empty
        cmbYear.SelectedIndex = -1
        tbPrice.Text = String.Empty
        chkNew.Checked = False

        lblResult.Text = String.Empty

        currentCarIdentificationNumber = String.Empty

    End Sub

    Private Function IsValidInput() As Boolean

        Dim returnValue As Boolean = True
        Dim outputMessage As String = String.Empty

        If cmbMake.SelectedIndex = -1 Then

            outputMessage += "Please select the appropriate car make." & vbCrLf

            returnValue = False

        End If

        If tbModel.Text.Trim.Length = 0 Then

            outputMessage += "Please enter the appropriate car model." & vbCrLf

            returnValue = False

        End If

        If cmbYear.SelectedIndex = -1 Then

            outputMessage += "Please select the appropriate year." & vbCrLf

            returnValue = False

        End If

        If tbPrice.Text.Trim.Length = 0 Then

            outputMessage += "Please enter an appropriate price." & vbCrLf

            returnValue = False

        End If

        If returnValue = False Then

            lblResult.Text = "ERRORS" & vbCrLf & outputMessage

        End If

        Return returnValue

    End Function

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click

        Reset()

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        Me.Close()

    End Sub

    Private Sub lvwCustomers_ItemCheck(sender As Object, e As ItemCheckEventArgs) Handles lvwCars.ItemCheck

        If editMode = False Then

            e.NewValue = e.CurrentValue

        End If

    End Sub

    Private Sub lvwCustomers_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvwCars.SelectedIndexChanged

        Const identificationSubItemIndex As Integer = 1

        currentCarIdentificationNumber = lvwCars.Items(lvwCars.FocusedItem.Index).SubItems(identificationSubItemIndex).Text

        Dim car As Car = CType(carList.Item(currentCarIdentificationNumber), Car)

        cmbMake.Text = car.Make
        tbModel.Text = car.Model
        cmbYear.Text = car.Year
        chkNew.Checked = car.NewCar

        lblResult.Text = car.GetInformation()


    End Sub

End Class