﻿Option Strict On
Public Class Class1

End Class